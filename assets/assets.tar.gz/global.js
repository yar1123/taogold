KISSY.ready(function(S){
	var D = S.DOM, E = S.Event, doc = document;
	
	/**
	 * 	对话框
	 */
	var Dialogue = {		
		show:function(title,width,height){
			var self = this;
			self._init();
			self._show(title,width,height);
			self.show = self._show;
		},
		_show:function(title,width,height){
			var self = this;
			self._el.style.display = 'block';
			self._titleEl.innerHTML = title || '对话框';
			if(width) self._el.style.width = width + 'px';
			if(height) self._el.style.height = height + 'px';				
			setTimeout(function(){
				var  l = (D.viewportWidth() - self._el.offsetWidth)/2, t = D.scrollTop() + (D.viewportHeight() - self._el.offsetHeight)/2;
				self._el.style.left =(l>0 ? l : 0) +'px';
				self._el.style.top = (t>0 ? t : 0)+'px';
			},0);
			
			_Mask.show();
		},
		hide:function(){
			var self = this;
			self._el.style.display = 'none';
			_Mask.hide();
		},
		append:function(el){
			var self = this;
			self._bdEl.appendChild(el);
		},
		_init:function(){
			var self = this;
			self._render();
		},
		_render:function(){
			var self = this, fragment = '';
			fragment += '<div class="box" style="display:none;position:absolute;width:944px;border:3px solid #ccc;z-index:100;">'
			fragment += '<div class="box-hd"><h3 class="box-title">选择宝贝</h3><div class="box-act"><a class="box-close" href="#">关闭</a></div></div>'
			fragment += '<div class="box-bd"></div>'
			fragment += '</div>'
			self._el = D.create(fragment);
			doc.body.appendChild(self._el);
			self._titleEl = D.get('.box-title',self._el);
			self._closeBtnEl = D.get('.box-close',self._el);
			self._bdEl = D.get('.box-bd',self._el);			
			E.on(self._closeBtnEl,'click',function(e){
				e.preventDefault();				
				self.hide();
			});
		},		
	}	
	
	var _Mask = {
		show:function(){
			var self = this;
			self._init();
			self._show();
			self.show = self._show;
		},
		_show:function(){
			var self = this;
			self._el.style.display = 'block';
			self._el.style.height = D.docHeight()+'px';			
		},
		hide:function(){
			var self = this;
			self._el.style.display = 'none';
		},
		_init:function(){
			var self = this;
			self._render();
		},
		_render:function(){
			var self = this;
			self._el = D.create('<div style = "display:none;position:absolute;width:100%;left:0;top:0;font-size:0px;line-height:0px;background:#000;filter:alpha(opacity=10);opacity:0.1;z-index:10;"></div>');
			doc.body.appendChild(self._el);			
		}
	}
	
	/**
	 * 选择框
	 */
	var CoupleSelect = function(src,target,itemCls){
		var self = this;
		self.srcEl = D.get(src);
		self.targetEl = D.get(target);
		self.itemCls = itemCls;
	};
	
	S.augment(CoupleSelect,{
		add:function(item){
			var self = this;
			self.targetEl.appendChild(item);
			var children = self.getTargetItems();
			if(children.length > 3) self.remove(children[0]);
		},
		remove:function(item){
			var self = this;
			self.srcEl.appendChild(item);
		},
		up:function(item){
			var self = this, prevItem = D.prev(item);
			if(prevItem) D.insertBefore(item,prevItem);
		},
		down:function(item){
			var self = this, nextItem = D.next(item);
			if(nextItem) D.insertAfter(item,nextItem);
		},
		getItem:function(t){
			var self = this;
			return D.parent(t,'.item')
		},
		getTargetItems:function(){
			var self = this;
			return D.children(self.targetEl,'.'+self.itemCls);
		}
	});
	
	/*************************************************************************************
	 * 新建模板-手工选择模板
	 *************************************************************************************/
	(function(){
		var trigger = D.get('#S_SelectItemTrigger');
		if(trigger){

			//渲染外框架
			var fragment = '<div class="couple-select" style="display:none;">';
			fragment += '<div class="couple-select-src">';
			fragment += '<div class="bar">店铺内的宝贝</div>';
			fragment += '<div class="bar"><form class="form"><select><option>所有类目…</option></select> <input type="text" /> <button class="button" type="button">搜索</button></form></div>';
			fragment += '<ul id="S_CoupleSelectSrc" class="item-list"></ul>';
			fragment += '</div>';
			fragment += '<div class="couple-select-target">';
			fragment += '<div class="bar">已推荐的宝贝（一共可推荐3个）</div>';
			fragment += '<ul id="S_CoupleSelectTarget" class="item-list"></ul>';
			fragment += '<div class="bar"><form class="form"><button id="S_CoupleSelectSubmit" class="button finish-select" disabled="disabled" type="button">我选好了</button></form></div>';
			fragment += '</div>';
			var selectWrapper = D.create(fragment);
			doc.body.appendChild(selectWrapper);
			var coupleSelect = new CoupleSelect(D.get('#S_CoupleSelectSrc'),D.get('#S_CoupleSelectTarget'),'item');
			
			//item模板
			var itemTemplate = '<li class="item"><div class="img"><image src="{pic_url}"/></div><a class="title" href="http://item.taobao.com/item.htm?id={num_iid}" target="_blank">{title}</a><span class="price">￥{price}</span><div class="operation"><a class="add" href="#">推荐</a><a class="moveup" href="#">上移</a><a class="movedown" href="#">下移</a><a class="remove" href="#">删除</a></div></li>';
			
			//定义获取的item信息
			var itemsInfo = [];			
			
			
			
			//绑定radio单击事件
			E.on(trigger,'click',function(e){
				Dialogue.show("选择宝贝");
				Dialogue.append(selectWrapper);	
				selectWrapper.style.display='block';
				if(itemsInfo.length == 0) getItems();				
			});

			//异步加载数据并渲染
			var getItems = function(){
				//获取item数据
				S.io.post(
					'onsales.html',
					null,
					function(o){
						var newItemsInfo = eval(o);						
						for(var i = 0, len = newItemsInfo.length; i < len; i ++ ){
							var item = D.create(S.substitute(itemTemplate,newItemsInfo[i]));
							item['data-item-info'] = newItemsInfo[i];
							D.get('#S_CoupleSelectSrc').appendChild(item);
						}
						itemsInfo = newItemsInfo;
					}
				);
			}	

			var checkSubmitBtn = function(){
				var btn = D.get('#S_CoupleSelectSubmit');
				if(coupleSelect.getTargetItems().length == 3){
					btn.disabled = false;
				}else{
					btn.disabled = true;
				}
			}

			//推荐
			E.on('#S_CoupleSelectSrc','click',function(e){
				var t = e.target;
				if(D.hasClass(t,'add')){
					coupleSelect.add(coupleSelect.getItem(t));
					checkSubmitBtn();
					e.preventDefault();
				}
			});	
			
			//上移，下移，移除
			E.on('#S_CoupleSelectTarget','click',function(e){
				var t = e.target;
				if(D.hasClass(t,'moveup')){
					coupleSelect.up(coupleSelect.getItem(t));
					e.preventDefault();
				}else if(D.hasClass(t,'movedown')){
					coupleSelect.down(coupleSelect.getItem(t));
					e.preventDefault();
				}else if(D.hasClass(t,'remove')){
					coupleSelect.remove(coupleSelect.getItem(t));
					checkSubmitBtn();
					e.preventDefault();
				}
			});	
			
			//提交数据
			E.on('#S_CoupleSelectSubmit','click',function(e){
				var targetItems = coupleSelect.getTargetItems(), targetItemsInfo = {};
				
				
			});
			
		}	
	})();
	
})








